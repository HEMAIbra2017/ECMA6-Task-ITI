


// sum fun that check if user write 2 param or more
function sum(...input) {

    if(input.length!=2){
         throw "You must input Two paramter";

        } else
          return " Yes , You enter Two paramter"
}
