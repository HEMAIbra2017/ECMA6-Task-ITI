

// export Polygon
      export  class  Polygon {
        constructor(width=0,height=0){
            this.width=width;
            this.height=height;
         }
    }
// export class Circle  that inherit from  Polygon
     export class Circle extends  Polygon{

        constructor(width=0){
            super(width,width);
        }
        tostring(){
          return `Area of Circle = ${Math.PI*this.width*this.width}`;
        }
    }
//  export class  Trianglethat inherit from   Polygon
      export class  Triangle extends  Polygon{

        constructor(width=0,height=0){
            super( width,height);

        }
        tostring(){
          return `Area of Triangle = ${0.5*this.height*this.width}`;
        }
    }
//export class  Rectangle that inherit from   Polygon
       export class  Rectangle extends  Polygon{

        constructor(width=0,height=0){
            super(width,height);
            ;
        }
        tostring(){
              return `Area of Rectangle = ${this.width*this.height} `;

        }
    }
//export class  Square that inherit from   Polygon
     export  class  Square extends Polygon{

        constructor(width=0){
            super(width,width);

        }
        tostring(){
              return `Area of Square = ${this.width*this.width} `;

        }
    }
