
let datatbl = document.getElementById("tb");

async function getData() {
    try {
        let response = await fetch('https://jsonplaceholder.typicode.com/users', {
            method: 'GET',
        })
        let users = await response.json()
        return users;
    } catch (error) {
        alert('Server is down')
    }

}

getData().then((data) => {
    let obj = data[0];
    let arrOfObj = [];
    let x, y;
    for (let i = 0; i < 10; i++) {
        arrOfObj = data[i]
        let arrOfValues = Object.values(arrOfObj);
        x = document.createElement("tr");
        datatbl.appendChild(x);
        for(let j=0; j<4;j++) {
            y = document.createElement("td");
            y.innerHTML = arrOfValues[j];
            x.appendChild(y);
        }
    }

})
