

let obj ={
    name:"Mohamed",
    address:"Cairo",
    age:27
}

let handler ={
    set:function(obj,prop,value){
       if (prop=="name"){
            if(value.length==7){
                obj[prop]=value
            }else{
              throw "must be 7 char"
           }
       }
         if (prop=="address"){
            if( typeof(value)=="string"){
               obj[prop]=value
            }else{
            throw "must be char only"
           }
       }
        if (prop=="age")
        {
            if(value>=25 && value <=60){
                obj[prop]=value
            }else{
              throw "age isn't in range"
           }
       }
    },
    get:function(obj,prop){
        return obj[prop]
    }
}

let objproxy = new Proxy(obj,handler)
