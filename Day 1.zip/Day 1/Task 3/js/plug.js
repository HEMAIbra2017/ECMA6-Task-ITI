
// fruits arr
var fruits = ["apple", "strawberry", "banana", "orange", "mango"];

function test(){
   var check=fruits.every((item)=>{
      return   typeof item=="string"
    })
    return check;
}

//strat fun
function start_a(){

 var check=fruits.some((item)=>{
    return  item.startsWith('a')
 })
 return check;
}

//filter
function filter(){
    var check=fruits.filter((item)=>{
       return  item.startsWith('b')||item.startsWith('s')
    })
    return check
 }

//
 function arrstr(){

     var check=fruits.map((item)=>{
         return ("I like"+item);

     })
     return check;
 }
 // dis fun
 function disp(){
     var array=arrstr(fruits);
     array.forEach(item =>console.log(item));
 }
 console.log(test())
 console.log(start_a())
 console.log(filter())
 console.log(arrstr())
 disp();
