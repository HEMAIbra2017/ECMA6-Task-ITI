
let arr=[];
function value(...arr){

// max
console.log("max:"+ Math.max(...arr[0]));
// min
console.log("min:"+Math.min(...arr[0]));
}
