
function courses(options={}){

    let info ={
        name:"c++",
        duration:"3 hours",
        namowner:"Mohamed"
    }
    let obj=Object.assign({},info,options);

    if (Object.keys(obj).length> 3)
             throw 'You`ve been sending more than 3 parametrs';
    return obj;
}
console.log(courses({
    name:"c#",
        namowner:"Aly"
    }
 ))
