
function swap(x,y){

let [a,b] = [x,y];

return [b,a]
}
