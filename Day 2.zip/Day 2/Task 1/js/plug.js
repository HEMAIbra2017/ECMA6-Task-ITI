

// generator returns fibonacci series

function* fib(value){
yield   n1 = 0, n2 = 1
console.log('Fibonacci Series:');
for (let i = 1; i <= value; i++) {
    temp = n1 + n2;

    n1 = n2;
    n2 = temp;
    if(temp<=value){
        console.log(temp);
    }
}
yield n1 = 0, n2 = 1
console.log('Fibonacci Series:');

for (let i = 1; i <= value; i++) {
    temp = n1 + n2;
    console.log(temp);
    n1 = n2;
    n2 = temp;
}
}
 let it = fib(8);
